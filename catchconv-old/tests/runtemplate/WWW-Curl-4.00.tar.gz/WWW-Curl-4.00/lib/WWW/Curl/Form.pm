package WWW::Curl::Form;
use strict;

# In development!
#
#require WWW::Curl;
#use vars qw(@ISA @EXPORT_OK);
#require Exporter;
#require AutoLoader;
# @ISA = qw(Exporter DynaLoader);

1;
