# $Id: Component.pm 2116 2006-09-08 04:45:45Z rcaputo $
# Copyrights and documentation are after __end__.

package POE::Component;

use strict;

use vars qw($VERSION);
$VERSION = do {my($r)=(q$Revision: 2116 $=~/(\d+)/);sprintf"1.%04d",$r};

1;

__END__

=head1 NAME

POE::Component - a POE servlet class

=head1 SYNOPSIS

Varies from component to component.

=head1 DESCRIPTION

POE components are event-driven modules, many of which act as little
daemons that supply services to the programs they're parts of.  In
general, they talk with other sessions by receiving and posting
events, but this is not a formal convention.  A component's interface
design should prefer to make sense; for example, an SMTP client should
have a method to just "send a message" rather than (or in addition to)
several others that deal with the intricacies of the SMTP protocol.

The POE::Component namespace was started as place for contributors to
publish their POE-based modules without requiring coordination with
the main POE distribution.

=head1 SEE ALSO

The SEE ALSO section in L<POE> contains a table of contents covering
the entire POE distribution.

=head1 TO DO

Document the customary (but not mandatory!) process of creating and
publishing a component.

=head1 AUTHORS & COPYRIGHTS

Each component is written and copyrighted by its author.

Please see L<POE> for more information about authors and contributors.

=cut
